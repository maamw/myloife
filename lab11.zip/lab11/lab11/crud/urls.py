from django.urls import path
from . import views
urlpatterns = [
    path('', views.index, name='index'),
    path('new_form', views.new_form, name='New_Form'),
    path('add_new', views.add_new, name='New_Record'),
    path('show', views.view_all, name='Show All Record'),
    path('edit/<int:id>', views.edit, name='Edit Record'),
    path('update/<int:id>', views.update),
    path('delete/<int:id>', views.delete, name='Delete Record'),
    path('search', views.search, name='Search Data'),

]
