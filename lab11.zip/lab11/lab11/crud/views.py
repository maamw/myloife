from django.shortcuts import render, redirect
from django.http import HttpResponse
from .forms import StudentsForm
from .models import Students


def index(request):
    return(render(request, 'index.html'))
def new_form(request):
    form = StudentsForm
    return (render(request, 'new_form.html', {'form':form}))

def add_new(request):
    form=StudentsForm(request.POST)
    form.save()
    return redirect('/show')

def view_all(request):
    stud = Students.objects.order_by('-id')
    return render(request,'view_all.html', {'stud': stud})

def edit(request, id):
    stud = Students.objects.get(id=id)
    return render(request,'edit.html', {'stud': stud})
def update(request, id):
    stud = Students.objects.get(id=id)
    if request.method == "POST":
        form = StudentsForm(request.POST, instance=stud)
        if form.is_valid():
            form.save()
            return redirect('/show')
        else:
            return (HttpResponse("Update Failed"))
def delete(request, id):
    stud = Students.objects.get(id=id)
    stud.delete()
    return redirect('/show')
def search(request):
    s_name = request.POST['sname']
    stud= Students.objects.filter(std_name__icontains=s_name)
    return render(request,'view_all.html',{'stud': stud})





